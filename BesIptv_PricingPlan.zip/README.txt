A Pen created at CodePen.io. You can find this one at https://codepen.io/mriptv/pen/oJmpZa.

 Pricing table with title, price and list.